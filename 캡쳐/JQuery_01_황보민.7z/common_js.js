
//================================================================================================================

	//*****************************************
	// Sungjuk이라는 이름의 [생성자함수] 선언
	//*****************************************
	
	function Sungjuk(stu_no, kor, eng, mat){
	//-------------------
	// 속성변수 선언
	//-------------------
	this.stu_no = stu_no;
	this.kor = kor;
	this.eng = eng;
	this.mat = mat;
	
	//-------------------
	// 메소드 선언
	//-------------------
	// 속성변수 stu_no 안의 데이터를 리턴하는 메소드 선언
	this.getStu_no = function() {
		//속성변수 stu_no 안의 데이터를 리턴하기
		return this.stu_no;
		}
	// 총점을 리턴하는 메소드 선언하기
	this.getTot = function(){
		//지역변수 tot 선언하고 국/영/수 점수를 더하여 저장하기
		var tot = this.kor + this.eng + this.mat;
		return tot;
			}
	// 평균을 리턴하는 메소드 선언하기
	this.getAvg = function(){
		//지역변수 avg 선언하고 국/영/수 점수의 평균을 구해 저장하기
		var avg = this.getTot()/3;
		return avg;
			}
	
	//------------------------------------------
	// 학점을 리턴하는 메소드 선언하기
	//------------------------------------------
	this.getHakjum = function(){
		
		var hakjum="F";
		var avg = this.getAvg();
		
		if(90<=avg && avg<=100){
			hakjum = "A";
			}
			else if(80<=avg && avg<90){
			hakjum = "B";
			}
			else if(70<=avg && avg<80){
			hakjum = "C";
			}
			else if(60<=avg && avg<70){
			hakjum = "D";
			}
		return hakjum;
		}		

	}

//================================================================================================================




function is_valid_jumin_num(jumin_num1, jumin_num2){
	
	if(jumin_num2==undefined){
		jumin_num2="";}

	var jumin_num = jumin_num1.concat(jumin_num2);
	if(checkPattern(jumin_num, /^[0-9]{7}$/, "주민번호 7자리를 바르게 입력하여 주십시오")==false){
		return false;}

	var gender = jumin_num.substr(6,1);
	var year = jumin_num.substr(0,2);
	if(gender=="1" || gender=="2"){
		year = "19" + year;
		}
		else if(gender=="3" || gender=="4"){
			year = "20" + year;
			}
			else{
			alert("주민등록번호 7번째 자리에는 1에서 4까지만 입력 가능합니다.");
			return false;
			}
	var month = jumin_num.substr(2,2);
	var date = jumin_num.substr(4,2);
	

	alert("year : " + year + "month : " + month + "date : " + date + "gender : " + gender);	

	
	if( is_future(year, month, date)==true ){
		alert("아직 존재하지 않는 주민번호입니다. 입력을 확인해 주십시오.");
		return false;
	}
	
	
	if( is_valid_YMD(year,month,date)==false){
		alert("합당한 주민번호가 존재하지 않습니다.");
		
		return false;

	}


	
	return true;
	}


	//***************************************************
	// 매개변수로 들어오는 문자열의  패턴을 검사하여 true 또는 false를 리턴하는 함수선언
	//***************************************************	
	function checkPattern(
	str //검사할 문자열
	,regExpObj //문자열의 패턴을 검사할 RegExp객체
	,alertmsg //문자열의 패턴이 틀릴 경우 보여줄 alert상자 안의 경고문자열
	){
	var result = regExpObj.test(str);
	if(result==false){
	 alert(alertmsg);
	 }
	 return result;
	}

	///*************************************
	// 아이디의 유효성체크 결과를 리턴하는 함수 선언
	///*************************************
	function checkID(
	str // 아이디가 들어올 매개변수
	){
	 //------------------------------------------------
	 // checkPattern 함수 호출로 아이디의 유효성 체크 결과를 얻어 리턴하기
	 //------------------------------------------------
	 return checkPattern(str,/^[a-z][a-z0-9_]{5,14}$/, 
	"[아이디 입력규칙]에 맞지 않습니다.\n<1>첫글자는 영소문자로 시작\n<2>영소문자, 숫자, 언더바(_)로 구성\n<3>7자 이상 15미만으로 구성");
	}
	///*************************************
	// 암호의 유효성 체크결과를 리턴하는 함수 선언
	///*************************************
	
	
	function checkPwd(str){
	 //------------------------------------------------
	 // checkPattern 함수 호출로 비밀번호의 유효성 체크 결과를 얻어 리턴하기
	 //------------------------------------------------
	 return checkPattern(str, /^[a-z0-9]{8,15}$/,
	"[암호 입력규칙]에 맞지 않습니다.\n<1>영소문자, 숫자로 구성\n<2>8자 이상 15미만으로 구성");
	}
	
	//****************************************************
	// checkbox 또는 radio 입력양식의 체크개수를 리턴하는 함수선언
	//****************************************************
	function getCheckedCnt(
		arrObj // checkbox 또는 radio객체가 저장된 Array객체의 메위주가 저장될 매개변수
	){
	//------------------------------------------------
	//체크된 개수를 저장할 변수 cnt 선언하기
	//------------------------------------------------
	var cnt = 0;
	//------------------------------------------------
	// checkbox 또는 radio 입력양식의 선택항목의 개수가 1개이면(=Array객체를 생성하지 않으면)
	// checked변수가 true인지를 구해서 리턴하기
	//------------------------------------------------
	if( arrObj.length==undefined ){
		if(arrObj.checked ==true){
		cnt=1;
			return cnt;
		}
	}
	//------------------------------------------------
	// checkbox 또는 radio 입력양식의 개수가 2개 이상이면
	// chedcked변수가 true인 개수를 구해서 리턴하기
	//------------------------------------------------
	for (var i=0; i<arrObj.length; i++){
		if(arrObj[i].checked==true){
			cnt++;
			}
		}
	return cnt;
	}

	
	//***************************************************
	// 존재하는 년월일인지의 여부를 체크하는 함수
	//***************************************************		
	function is_valid_YMD (year, month, date){
	//매개변수로 들어온 숫자문자를 숫자로 바꾸기
	var year = parseInt(year, 10);
	var month =	parseInt(month, 10);
	var date = parseInt(date, 10);
	//생일 날짜를 관리하는 년,월,일 얻기
	var birthday = new Date(year, month-1, date);
	//Date객체에서 년,월,일 얻기
	var year2 = birthday.getFullYear();
	var month2 = birthday.getMonth()+1;
	var date2 = birthday.getDate();
	//매개변수로 들어온 데이터와 Date객체로부터 얻은 데이터 중 다른 데이터가 있다면 false 저장
	if( year!=year2 || month!=month2 || date!=date2){
		return false;
	}
	else{
		return true;
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// 존재하는 연월일인지의 여부를 체크하는 함수 선언
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function checkBirthday(){
		//선택한 출생년도 얻기
		var year = document.memberRegForm.birth_year.value;
		//선택한 출생월 얻기
		var month = document.memberRegForm.birth_month.value;
		//선택한 출생일 얻기
		var date = document.memberRegForm.birth_date.value;
		//만약 연도, 월, 일 중 하나가 없으면 함수를 중단하기
		if( year == "" || month == "" || date == "" ){return;}

		if(is_valid_YMD( year, month, date )==false){
		alert("선택하신 생년월일이 존재하지 않습니다.");
		return;
		}

		//********************************************
		// 존재하는 연월일인지의 여부를 체크하는 함수
		//********************************************
		var xxx = confirm("존재하지 않는 날짜입니다. 입력가능한 마지막 일수로 변경할까요?");
		if(xxx==true){
		//선택한 년월의 마지막 날자 구하기
		var date_new = new Date(
		parseInt(year,10)
		, parseInt(month,10)
		, 0 );

	// 선택한 년월의 마지막 날짜를 관리하는 dateObj 객체 생성하기
	var lastDate = dateObj.getDate();
	document.memberRegForm.birth_date.value = lastDate;
			}
			else{
		document.memberRegForm.birth_year.value="";
		document.memberRegForm.birth_month.value="";
		document.memberRegForm.birth_date.value="";
			}
		}
	


	
	
	function is_future(year, month, date) {
		try{	
			// 현재 시스템 날짜를 관리하는 Date객체 생성하기	
			var today = new Date();
			// 매개변수로 들어온 년월일을 관리하는 Date객체 생성하기
			var xxday = new Date(
			parseInt(year,10)
			, parseInt(month,10)-1
			, parseInt(date,10)
			);
			
			//매개변수로 들어온 년월일이 현재 시스템 날짜의 년월일보다 크면 true 리턴
			if(xxday.getTime()>today.getTime()){
				return true;
				}
			//그 외의 경우 false리턴하기
			else{
				return false;
				}
		}catch(ex){
			alert("예외발생! " + ex.message + ", 매개변수 년,월,일이 이 정확히 들어와야 합니다." );
			alert("예외발생! " + year + " " + month + " " + date );
		}

	}



	//*******************************************************
	// 길이가 없는 문자열이거나, 공백으로 이루어진 문자이거나, null/undefined일 경우에 true를 리턴하는 함수 리턴하기
	//*******************************************************

	function isEmpty(xxx){

		var regExp = new RegExp(/^[ ]+$/);

		var result = false;
		if( xxx == null || xxx == undefined ){
			result = true;
		}
		else if( xxx == "" || ( regExp.test(xxx)==true )){
			result = true;
		}
		
		return result;
	}

