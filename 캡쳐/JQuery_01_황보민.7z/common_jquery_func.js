


function insertYMD_to_select3(

	
		yearObj 	//연도관련 select태그를 관리하는 JQuery객체
		,monthObj	//월 관련 select태그를 관리하는 JQuery객체
		,dateObj	//일 관련 select태그를 관리하는 JQuery객체

		,min_year	//입력할 연도의 최소값
		,max_year	//입력할 연도의 최대값
		,year_asc_or_desc //연도의 오름차순 또는 내림차순 옵션, 1이면 내림차순, 입력되지 않거나 1이 아니면 오름차순
	){
	
	try{
	//----------------------------------------------
	// 매개변수 year_asc_or_desc가 undefined(매개변수가 입력되지 않음)이면,  year_asc_or_desc값을 1로 설정하기
	//-----------------------------------------------
	//if(year_asc_or_desc==undefined){year_asc_or_desc == 1;}
	
	//----------------------------------------------
	// 반복문을 사용하여 class=birth_year를 가진 태그 내부에 option태그를 막내 태그로 삽입하기
	// 연도표기관련 option태그를 막내아들로 삽입하기
	//-----------------------------------------------
	if(year_asc_or_desc==1){
		for(var i=min_year; i<=max_year; i++){
			yearObj.prepend("<option value='"+i+"'>"+i+"</option>");
			}
		}
		else{
		for(var i=min_year; i<=max_year; i++){
			yearObj.append("<option value='"+i+"'>"+i+"</option>");
			}	
		}
	//----------------------------------------------
	// 반복문을 사용하여 class=birth_month를 가진 태그 내부에 option태그를 막내 태그로 삽입하기
	// 월 표기관련 option태그를 막내아들로 삽입하기
	//-----------------------------------------------
	for( var i=1; i<=12; i++){
		if(i<10)
			monthObj.append("<option value='0"+i+"'>0"+i+"</option>");
		else{																
			monthObj.append("<option value='"+i+"'>"+i+"</option>");
				}
			}
	//----------------------------------------------
	// 반복문을 사용하여 class=birth_year를 가진 태그 내부에 option태그를 막내 태그로 삽입하기
	// 일 표기관련 option태그를 막내아들로 삽입하기
	//-----------------------------------------------	
	for(var i=1; i<=31; i++){
		if(i<10){
			dateObj.append("<option value=0'"+i+"'>0"+i+"</option>"); }
		else{
			dateObj.append("<option value='"+i+"'>"+i+"</option>");
			}

		}
	  }
	  catch(ex){
		alert("insertYMD_to_select3 함수의 매개변수로 '연도,월,일 select태그를 관리하는 각 JQuery객체의 메위주',\n"
			+"최소연도, 최대연도 (,오름/내림차순옵션)을 순서대로 입력해 주십시오." + ex.message);
					
	  }
	}
	


	//*************************************************
	//*************************************************
	//*************************************************
	function insertValidDate(
		yearObj		// 연도 관련 select태그를 관리하는 JQuery객체
		,monthObj		// 월 관련 select태그를 관리하는 JQuery객체
		,dateObj		// 일 관련 select태그를 관리하는 JQuery객체
	){
		try{	
		//-----------------------------------------------------------------
		// 연도관련 태그를 관리하는 JQuery객체의 val메소드 호출로
		// 연도관련 태그의 value값 얻기 = 선택한 연도 얻기
		//-----------------------------------------------------------------
		var birth_year = yearObj.val();
		//-----------------------------------------------------------------
		// 월관련 태그를 관리하는 JQuery객체의 val메소드 호출로
		// 월 관련 태그의 value값 얻기 = 선택한 월 얻기
		//-----------------------------------------------------------------
		var birth_month = monthObj.val();
		//-----------------------------------------------------------------
		// 일 관련 태그를 관리하는 JQuery객체의 val메소드 호출로
		// 일 관련 태그의 value값 얻기 = 선택한 일 얻기
		//-----------------------------------------------------------------
		var birth_date = dateObj.val();
		 
		//-----------------------------------------------------------------
		// 연도와 월 데이터가 입력되어 있으면
		//----------------------------------------------------------------- 
		if( birth_year!="" && birth_month!="" ){
			//연도와 월에 해당하는 마지막 날짜를 관리하는 Date객체를 생성하고 선택 연월의 마지막 일 수를 얻기
			var last_date = new Date(
				parseInt(birth_year,10)
				,parseInt(birth_month,10)
				,0
				).getDate();
		//-----------------------------------------------------------------
		// 일을 표현하는 태그를 JQuery객체의 empty메소드를 호출하여
		// 일을 표현하는 태그의 내부를 비우기 = 일을 표현하는 태그의 내부 option태그를 모두 없애기
		//-----------------------------------------------------------------
		dateObj.empty();
		//-----------------------------------------------------------------
		// 일을 표현하는 태그를 JQuery객체의 append메소드를 호출하여
		// 일을 표현하는 태그의 내부에 1~마지막 일 수까지 표현하기
		//-----------------------------------------------------------------
		dateObj.append("<option value=''></option>");
		for( var i=1; i<=last_date ; i++){
		if(i<10){
			dateObj.append("<option value=0" +i+ ">0" +i+ "</option>");		
			}
			else{
			dateObj.append("<option value=" +i+ ">" +i+ "</option>");
			}
		}	
			//-----------------------------------------------------------------
			// 선택한 일 셀렉트가 비어있지 않을 경우
			//-----------------------------------------------------------------
			if( birth_date!="" ) {
				//일을 표현하는 태그를 JQuery객체의 val메소드를 호출하여 원래 선택한 일 데이터로 다시 선택하게 하기
				dateObj.val(birth_date);	
			}
		}
	}catch(ex){
		alert( "insertValidDate 함수 호출 시 예외발생! 흑흑흑");

		}
	}

	function checkCalender123(yearObj, monthObj, dateObj){ 
	
	var birth_year = yearObj; 	
	var birth_month = monthObj;
	var birth_date = dateObj;

		var str = "";
			if ( isEmpty(birth_year) ) { str += "0"; }
				else			    	{ str += "1"; }
			if ( isEmpty(birth_month) ) { str += "0"; }
				else				    { str += "2"; }
			if ( isEmpty(birth_date) ) { str += "0"; }
				else				    { str += "3"; }
			
			if ( str.indexOf("003")>=0 ){
				alert("연도를 먼저 입력해 주십시오.");
				dateObj.val("");
				yearObj.focus();
				return;
			}
			if ( str.indexOf("02")>=0 ){
				alert("연도를 먼저 입력해 주십시오.");
				monthObj.val("");
				yearObj.focus();
				return;
			}
			if ( str.indexOf("03")>=0 ){
				alert("월을 먼저 입력해 주십시오.");
				dateObj.val("");
				monthObj.focus();
				return;
			}
			if( str == "000" ){	
			insertValidDate( yearObj,  monthObj, dateObj );
						}
	
	}